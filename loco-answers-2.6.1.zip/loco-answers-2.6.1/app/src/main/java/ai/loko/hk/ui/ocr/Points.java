package ai.loko.hk.ui.ocr;

public class Points {
    public static float X1, Y1, X2, Y2;
}
